# Third-party notices

## Pokesurvivor game

Both apps load the live game at [pokesurvivor.com](https://pokesurvivor.com/). The game and its content belong to their respective creators and rights holders. They are not relicensed by this repository's MIT license. No game source or game assets are bundled in these Android projects.

Consult the game's own legal notice and credits for its content and dependencies.

## Gradle Wrapper

Each Android project includes generated Gradle Wrapper scripts and a wrapper JAR for Gradle 8.11.1. Gradle components retain their existing copyright and licensing notices and are not relicensed under MIT.

The Gradle distribution's [license](third-party/gradle-LICENSE.txt) and [notice](third-party/gradle-NOTICE.txt) are included. Existing license headers in the generated wrapper scripts are preserved.

## Scope of the MIT license

The root MIT license applies to the original Android wrapper implementation, JavaScript adapter, custom launcher artwork and documentation authored for this project. It does not grant rights to the external game, Pokémon content, Gradle or other third-party materials.
