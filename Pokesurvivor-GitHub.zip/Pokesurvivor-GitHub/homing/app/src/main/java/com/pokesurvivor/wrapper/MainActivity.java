package com.pokesurvivor.wrapper;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.hardware.input.InputManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.webkit.*;
import android.widget.*;
import java.nio.charset.StandardCharsets;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity implements InputManager.InputDeviceListener {
    private WebView web;
    private String script;
    private boolean ready;
    private int activeController = -1;
    private float stickX, stickY, hatX, hatY;
    private final Set<Integer> dpad = new HashSet<>();
    private InputManager inputs;
    private LinearLayout error;
    private static final String HOME = "https://pokesurvivor.com/";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        if (android.os.Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp=getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode=WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_NEVER;
            getWindow().setAttributes(lp);
        }
        try (InputStream source=getAssets().open("controller.js"); ByteArrayOutputStream buffer=new ByteArrayOutputStream()) {
            byte[] chunk=new byte[8192]; int count;
            while((count=source.read(chunk))!=-1) buffer.write(chunk,0,count);
            script=new String(buffer.toByteArray(),StandardCharsets.UTF_8);
        }
        catch (Exception e) { throw new IllegalStateException("Missing controller adapter",e); }
        FrameLayout root = new FrameLayout(this); root.setBackgroundColor(Color.rgb(16,30,43));
        web = new WebView(this);
        web.setFocusable(true); web.setFocusableInTouchMode(true);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false); s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setSupportMultipleWindows(false);
        CookieManager.getInstance().setAcceptCookie(true);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView v,String url,android.graphics.Bitmap icon) { ready=false; clearState(); }
            @Override public void onPageFinished(WebView v,String url) {
                if (trusted(url)) { ready=true; v.evaluateJavascript(script,null); }
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                if(trusted(r.getUrl().toString())) return false;
                if(r.isForMainFrame()) {
                    String scheme=r.getUrl().getScheme();
                    if("https".equals(scheme)||"http".equals(scheme)||"mailto".equals(scheme)) {
                        try { startActivity(new Intent(Intent.ACTION_VIEW,r.getUrl())); } catch(Exception ignored) {}
                    }
                }
                return true;
            }
            @Override public void onReceivedError(WebView v,WebResourceRequest r,WebResourceError e) { if(r.isForMainFrame()) showError(); }
            @Override public void onReceivedHttpError(WebView v,WebResourceRequest r,WebResourceResponse e) { if(r.isForMainFrame() && e.getStatusCode()>=400) showError(); }
        });
        root.addView(web,new FrameLayout.LayoutParams(-1,-1));
        Button tools=new Button(this); tools.setText("☰"); tools.setTextSize(18); tools.setContentDescription("App controls and keyboard"); tools.setAlpha(.82f);
        FrameLayout.LayoutParams tp=new FrameLayout.LayoutParams(dp(48),dp(48),Gravity.TOP|Gravity.RIGHT);
        tp.topMargin=dp(6); tp.rightMargin=dp(6); root.addView(tools,tp); tools.setOnClickListener(v->showTools());
        error=new LinearLayout(this); error.setOrientation(LinearLayout.VERTICAL); error.setGravity(Gravity.CENTER); error.setBackgroundColor(Color.rgb(16,30,43));
        TextView message=new TextView(this); message.setText("Pokesurvivor couldn’t load.\nCheck your internet connection and try again."); message.setTextColor(Color.WHITE); message.setGravity(Gravity.CENTER); error.addView(message);
        Button retry=new Button(this); retry.setText("Retry"); retry.setOnClickListener(v->{error.setVisibility(View.GONE); web.loadUrl(HOME);}); error.addView(retry); error.setVisibility(View.GONE); root.addView(error,new FrameLayout.LayoutParams(-1,-1));
        setContentView(root);
        inputs=(InputManager)getSystemService(INPUT_SERVICE);
        inputs.registerInputDeviceListener(this,null);
        web.loadUrl(HOME); immersive();
    }
    private int dp(int n) { return Math.round(n*getResources().getDisplayMetrics().density); }
    private boolean trusted(String url) { Uri u=Uri.parse(url); return "https".equals(u.getScheme()) && "pokesurvivor.com".equals(u.getHost()); }
    private void js(String value) { if(ready && trusted(web.getUrl())) web.evaluateJavascript("window.PSAndroid&&"+value,null); }
    private void showError() { ready=false; error.setVisibility(View.VISIBLE); }
    private void immersive() { getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION); }
    private void showTools() {
        clearState(); js("PSAndroid.pause()");
        new AlertDialog.Builder(this).setTitle("Pokesurvivor Homing").setItems(new String[]{"Controls guide","Show keyboard","Reload game","Close app"},(dialog,which)->{
            if(which==0) new AlertDialog.Builder(this).setTitle("Controls")
                .setMessage("GAMEPAD\nLeft stick: movement\nAim: automatically targets enemies\nAutomatic firing: normal move cooldown; no trigger needed\nD-pad Up / Right / Down / Left: moves 1 / 2 / 3 / 4\nY: cycle to next move\nR1: zoom in · L1: zoom out\nStart: pause / resume\nL3: reroll upgrades\nSelect: app menu\n\nMENUS\nA: select or edit a field\nB: back or close keyboard\nLeft stick / D-pad: focus choices\n\nKEYBOARD / MOUSE\nWASD / arrows: move\nTargeting and firing are automatic\n1–4: choose move or upgrade\nQ / E: cycle moves\nEscape / P: pause\nR: reroll upgrades\nTab / Shift+Tab: sign-in fields\nEnter: submit sign-in\n\nThis version restores normal automatic enemy targeting and attacks. Homing, chain and area moves retain their intrinsic behavior. Button labels follow Android positions.")
                .setPositiveButton("Got it",null).show();
            else if(which==1) { js("PSAndroid.reset();(document.querySelector('#scr-login:not(.hidden) input')||document.querySelector('input:not([type=hidden])'))?.focus()"); web.requestFocus(); web.postDelayed(()->((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).showSoftInput(web,InputMethodManager.SHOW_IMPLICIT),150); }
            else if(which==2) new AlertDialog.Builder(this).setMessage("Reloading ends the current run. Reload?").setNegativeButton("Cancel",null).setPositiveButton("Reload",(d,w)->web.reload()).show();
            else finish();
        }).show();
    }
    private boolean controller(KeyEvent e) {
        InputDevice device=e.getDevice(); if(device==null) return false;
        int sources=device.getSources();
        return (sources&InputDevice.SOURCE_GAMEPAD)==InputDevice.SOURCE_GAMEPAD || (sources&InputDevice.SOURCE_JOYSTICK)==InputDevice.SOURCE_JOYSTICK;
    }
    private String button(int k) {
        switch(k) {
            case KeyEvent.KEYCODE_BUTTON_A:return "a"; case KeyEvent.KEYCODE_BUTTON_B:return "b";
            case KeyEvent.KEYCODE_BUTTON_X:return "x"; case KeyEvent.KEYCODE_BUTTON_Y:return "y";
            case KeyEvent.KEYCODE_BUTTON_L1:return "lb"; case KeyEvent.KEYCODE_BUTTON_R1:return "rb";
            case KeyEvent.KEYCODE_BUTTON_R2:return "rt";
            case KeyEvent.KEYCODE_BUTTON_START:return "start"; case KeyEvent.KEYCODE_BUTTON_THUMBL:return "reroll";
            case KeyEvent.KEYCODE_DPAD_UP:return "up"; case KeyEvent.KEYCODE_DPAD_DOWN:return "down";
            case KeyEvent.KEYCODE_DPAD_LEFT:return "left"; case KeyEvent.KEYCODE_DPAD_RIGHT:return "right";
        } return null;
    }
    @Override public boolean dispatchKeyEvent(KeyEvent e) {
        // Physical keyboards and IMEs go directly to WebView: never steal login typing.
        if(!controller(e)) return super.dispatchKeyEvent(e);
        if(e.getAction()!=KeyEvent.ACTION_DOWN && e.getAction()!=KeyEvent.ACTION_UP) return super.dispatchKeyEvent(e);
        if(!ready) return super.dispatchKeyEvent(e);
        if(activeController!=-1 && activeController!=e.getDeviceId()) { clearState(); js("PSAndroid.reset()"); }
        activeController=e.getDeviceId();
        boolean down=e.getAction()==KeyEvent.ACTION_DOWN;
        if(e.getKeyCode()==KeyEvent.KEYCODE_BUTTON_SELECT || e.getKeyCode()==KeyEvent.KEYCODE_BUTTON_MODE) { if(down && e.getRepeatCount()==0) showTools(); return true; }
        String name=button(e.getKeyCode()); if(name==null) return super.dispatchKeyEvent(e);
        if(e.getRepeatCount()>0) return true;
        js("PSAndroid.button('"+name+"',"+down+")"); return true;
    }
    private float centered(MotionEvent e,int axis) {
        InputDevice.MotionRange range=e.getDevice().getMotionRange(axis,e.getSource());
        float value=e.getAxisValue(axis), flat=range==null?.18f:Math.min(.95f,Math.max(.18f,range.getFlat()));
        return Math.abs(value)<=flat?0:Math.copySign(Math.min(1,(Math.abs(value)-flat)/(1-flat)),value);
    }
    @Override public boolean dispatchGenericMotionEvent(MotionEvent e) {
        if((e.getSource()&InputDevice.SOURCE_JOYSTICK)==InputDevice.SOURCE_JOYSTICK && e.getAction()==MotionEvent.ACTION_MOVE && ready) {
            if(activeController!=-1 && activeController!=e.getDeviceId()) { clearState(); js("PSAndroid.reset()"); }
            activeController=e.getDeviceId();
            stickX=centered(e,MotionEvent.AXIS_X); stickY=centered(e,MotionEvent.AXIS_Y);
            hatX=e.getAxisValue(MotionEvent.AXIS_HAT_X);hatY=e.getAxisValue(MotionEvent.AXIS_HAT_Y);
            hat(KeyEvent.KEYCODE_DPAD_LEFT,hatX<-.5f);hat(KeyEvent.KEYCODE_DPAD_RIGHT,hatX>.5f);
            hat(KeyEvent.KEYCODE_DPAD_UP,hatY<-.5f);hat(KeyEvent.KEYCODE_DPAD_DOWN,hatY>.5f);
            float aimX=centered(e,MotionEvent.AXIS_Z),aimY=centered(e,MotionEvent.AXIS_RZ);
            if(e.getDevice().getMotionRange(MotionEvent.AXIS_Z,e.getSource())==null) {
                aimX=centered(e,MotionEvent.AXIS_RX);aimY=centered(e,MotionEvent.AXIS_RY);
            }
            float rt=e.getAxisValue(MotionEvent.AXIS_RTRIGGER);
            if(e.getDevice().getMotionRange(MotionEvent.AXIS_RTRIGGER,e.getSource())==null) rt=e.getAxisValue(MotionEvent.AXIS_GAS);
            js(String.format(Locale.US,"PSAndroid.aim(%.4f,%.4f)",aimX,aimY));
            if(e.getDevice().getMotionRange(MotionEvent.AXIS_RTRIGGER,e.getSource())!=null || e.getDevice().getMotionRange(MotionEvent.AXIS_GAS,e.getSource())!=null)
                js(String.format(Locale.US,"PSAndroid.trigger(%.4f)",rt));
            publishAxis();return true;
        } return super.dispatchGenericMotionEvent(e);
    }
    private void publishAxis() {
        float x=stickX, y=stickY;
        float magnitude=(float)Math.hypot(x,y);if(magnitude>1){x/=magnitude;y/=magnitude;}
        js(String.format(Locale.US,"PSAndroid.axis(%.4f,%.4f)",x,y));
    }
    private void hat(int key,boolean down) {
        if(dpad.contains(key)==down)return;
        if(down)dpad.add(key);else dpad.remove(key);
        js("PSAndroid.button('"+button(key)+"',"+down+")");
    }
    private void clearState(){stickX=stickY=hatX=hatY=0;dpad.clear();activeController=-1;}
    @Override public void onInputDeviceRemoved(int id) { if(id==activeController){clearState();js("PSAndroid.reset()");} }
    @Override public void onInputDeviceAdded(int id) {}
    @Override public void onInputDeviceChanged(int id) { onInputDeviceRemoved(id); }
    @Override public void onWindowFocusChanged(boolean focus) {super.onWindowFocusChanged(focus);if(focus)immersive();else {clearState();js("PSAndroid.reset()");}}
    @Override protected void onPause(){clearState();js("PSAndroid.pause()");web.onPause();super.onPause();CookieManager.getInstance().flush();}
    @Override protected void onResume(){super.onResume();if(web!=null)web.onResume();}
    @Override public void onBackPressed(){ if(ready){js("PSAndroid.back()");}else super.onBackPressed(); }
    @Override protected void onDestroy(){inputs.unregisterInputDeviceListener(this);web.destroy();super.onDestroy();}
}
