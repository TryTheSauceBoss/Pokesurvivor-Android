(() => {
  'use strict';
  if (window.PSAndroid) return;
  let axis = [0, 0], held = new Set(), nextNav = 0, navDirection = '', patched;
  let aimAngle = Math.PI/2, trigger = false, keyboardFire = false, mouseAim = false, zoom = 1;
  let playerPatched, combatPatched, cameraPatched, lastScan = -Infinity;
  const editable = el => !!el && (el.matches('input,textarea,select') || el.isContentEditable);
  const visible = el => !!el && el.getClientRects().length > 0 && getComputedStyle(el).visibility !== 'hidden';
  const gameplay = () => window.G?.Game?.state === 'playing' &&
    !Array.from(document.querySelectorAll('.scr')).some(visible) && !G.SettingsUI?.isOpen;
  const codes = { up: ['Digit1','1'], right: ['Digit2','2'], down: ['Digit3','3'], left: ['Digit4','4'],
    y:['KeyE','e'], start:['Escape','Escape'], reroll:['KeyR','r'] };
  function key(code, value, down) {
    window.dispatchEvent(new KeyboardEvent(down ? 'keydown' : 'keyup', { code, key:value, bubbles:true, cancelable:true }));
  }
  function tap(code, value) {
    key(code, value, true);
    // Keep pressed long enough for the game's next frame, including low-FPS devices.
    setTimeout(() => key(code, value, false), 80);
  }
  function candidates() {
    const screens = Array.from(document.querySelectorAll('.scr,[role="dialog"]')).filter(visible);
    const scope = screens.at(-1) || document;
    return Array.from(scope.querySelectorAll('button,input,select,textarea,a[href],[tabindex],.card,.cell,.tab,[role="button"],[data-tab],[data-menu]'))
      .filter(el => visible(el) && !el.disabled && el.getAttribute('aria-disabled') !== 'true' && el.type !== 'hidden');
  }
  function navigate(direction) {
    const list = candidates(); if (!list.length) return;
    const current = document.activeElement;
    if (!list.includes(current)) { list[0].focus(); list[0].scrollIntoView({block:'nearest'}); return; }
    const r = current.getBoundingClientRect(), cx = r.x+r.width/2, cy = r.y+r.height/2;
    let best, score = Infinity;
    for (const el of list) {
      if (el === current) continue;
      const b = el.getBoundingClientRect(), dx = b.x+b.width/2-cx, dy = b.y+b.height/2-cy;
      const primary = direction==='left' ? -dx : direction==='right' ? dx : direction==='up' ? -dy : dy;
      const cross = direction==='left'||direction==='right' ? Math.abs(dy) : Math.abs(dx);
      const cost = primary + cross*3;
      if (primary > 4 && cost < score) { score = cost; best = el; }
    }
    best ||= list[(list.indexOf(current)+(direction==='left'||direction==='up' ? -1 : 1)+list.length)%list.length];
    best.focus(); best.scrollIntoView({block:'nearest',inline:'nearest'});
  }
  function back() {
    if (editable(document.activeElement)) { document.activeElement.blur(); return; }
    const buttons = candidates().filter(el => el.matches('button') && /^(volver|cerrar|atrás|back|close|cancel|cancelar|continuar|resume)$/i.test(el.textContent.trim()));
    if (buttons.length) buttons.at(-1).click(); else tap('Escape','Escape');
  }
  function reset() {
    axis = [0,0]; trigger = false; keyboardFire = false; nextNav = 0; navDirection = '';
    for (const name of held) if (codes[name]) key(...codes[name], false);
    held.clear();
    window.dispatchEvent(new Event('blur'));
  }
  window.PSAndroid = {
    axis(x,y) { axis = [x,y]; },
    aim(x,y) { if(Math.hypot(x,y)>.1) { aimAngle=Math.atan2(y,x); mouseAim=false; } },
    trigger(value) { trigger = value > .25; },
    pause() { reset(); if(window.G?.Game?.state==='playing') G.Game.togglePause(); },
    reset,
    button(name, down) {
      if (!down) { held.delete(name); if(name==='rt') trigger=false; if(codes[name]) key(...codes[name], false); return; }
      if (held.has(name)) return;
      held.add(name);
      if (name === 'start') { tap('Escape','Escape'); return; }
      if (gameplay() && !editable(document.activeElement)) {
        if(name==='rt') { trigger=true; return; }
        if(name==='lb'||name==='rb') {
          zoom=Math.max(.75,Math.min(1.75,zoom+(name==='rb'?.1:-.1)));
          const canvas=document.getElementById('game'); if(canvas && window.G?.Camera) G.Camera.resize(canvas.clientWidth,canvas.clientHeight,G.Camera.dpr);
          return;
        }
        if(codes[name]) key(...codes[name], true); return;
      }
      if (['up','down','left','right'].includes(name)) return; // repeat navigation is handled by tick
      if (name==='a') {
        if (visible(document.getElementById('tap-start'))) { document.getElementById('tap-start').click(); return; }
        let el = document.activeElement;
        if (!candidates().includes(el)) { el=candidates()[0]; el?.focus(); }
        el?.click();
      } else if (name==='b') back();
      else if(name==='lb'||name==='rb') navigate(name==='lb'?'left':'right');
      else if(name==='reroll') tap('KeyR','r');
    },
    back
  };
  const style = document.createElement('style');
  style.textContent = ':focus-visible{outline:3px solid #ffd26b!important;outline-offset:3px!important} [data-ps-focus]:focus{outline:3px solid #ffd26b!important;outline-offset:3px!important}';
  document.head.appendChild(style);
  function tick(now) {
    if (window.G?.Input && patched !== G.Input) {
      patched = G.Input;
      const original = G.Input.axis.bind(G.Input);
      G.Input.axis = () => gameplay() && !editable(document.activeElement) && (axis[0]||axis[1]) ? axis.slice() : original();
    }
    if(window.G?.Player && playerPatched!==G.Player.prototype) {
      playerPatched=G.Player.prototype;
      const update=playerPatched.update;
      playerPatched.update=function(dt) {
        update.call(this,dt);
        if(this!==G.Game.player || this.dead) return;
        if(mouseAim && G.Input.mouse) {
          const mouse=G.Input.mouse(), c=G.Camera;
          aimAngle=Math.atan2(c.top()+mouse.y/c.scale-this.y,c.left()+mouse.x/c.scale-this.x);
        }
        this.aim=aimAngle;
        // Directional casts use the stick direction even when no enemy is nearby.
        // Homing/chain moves keep their original targeting behavior.
        const move=this.activeMove();
        if(move && ['projectile','beam','melee','boomerang','dash','cone'].includes(move.kind))
          this.target={x:this.x+Math.cos(aimAngle)*24,y:this.y+Math.sin(aimAngle)*24,dead:false};
        this.anim.dir=G.Sprites.dirFromAngle(this.attackFace>0||!this.walking?this.aim:this.moveAngle);
      };
    }
    if(window.G?.Combat && combatPatched!==G.Combat) {
      combatPatched=G.Combat;
      const original=G.Combat.tick;
      G.Combat.tick=function(dt,player,time) {
        if(player!==G.Game.player) return original.call(this,dt,player,time);
        const firing=gameplay() && !editable(document.activeElement) && (trigger || keyboardFire || G.Input.mouse?.().down);
        if(firing) return original.call(this,dt,player,time);
        // Advance cooldowns without casting. Existing projectiles/effects expire normally.
        for(const move of player.activeGroup()) if(move.kind!=='orbit') move.t=Math.max(0,move.t-dt);
      };
    }
    if(window.G?.Camera && cameraPatched!==G.Camera) {
      cameraPatched=G.Camera; const resize=G.Camera.resize;
      G.Camera.resize=function(w,h,dpr=1) { resize.call(this,w,h,dpr); this.scale*=zoom;this.w/=zoom;this.h/=zoom; };
    }
    if(now-lastScan>200) {
      lastScan=now;
      for (const el of candidates()) {
        if (!el.matches('button,input,select,textarea,a[href],[tabindex]')) el.tabIndex=0;
        el.setAttribute('data-ps-focus','');
      }
    }
    if (!gameplay()) {
      let dx=axis[0],dy=axis[1];
      if(held.has('left'))dx=-1; if(held.has('right'))dx=1;
      if(held.has('up'))dy=-1; if(held.has('down'))dy=1;
      const dir = Math.max(Math.abs(dx),Math.abs(dy)) < .5 ? '' : Math.abs(dx)>Math.abs(dy) ? (dx<0?'left':'right') : (dy<0?'up':'down');
      if (dir && (dir!==navDirection||now>=nextNav)) { navigate(dir); nextNav=now+(dir!==navDirection?350:140); }
      navDirection=dir;
    }
    requestAnimationFrame(tick);
  }
  // Capture typing before the game's global key listeners see it; native WebView
  // still performs text entry, Tab traversal and form submission normally.
  for (const type of ['keydown','keyup']) window.addEventListener(type, event => {
    if (editable(event.target)) {
      event.stopImmediatePropagation();
      if(type==='keydown' && event.key==='Escape') { event.target.blur(); event.preventDefault(); }
      return;
    }
    if(event.code==='Space') { keyboardFire=type==='keydown'; event.preventDefault(); }
    if(event.key==='Tab' && !gameplay()) event.stopImmediatePropagation();
    if(type==='keydown' && event.key==='Enter' && document.activeElement?.matches('.card,.cell,.tab,[role="button"],[data-tab],[data-menu]')) {
      document.activeElement.click(); event.preventDefault();
    }
  }, true);
  window.addEventListener('mousemove',()=>{mouseAim=true;});
  document.addEventListener('focusin', event => { if(editable(event.target)) reset(); });
  document.addEventListener('visibilitychange', () => { if(document.hidden) reset(); });
  requestAnimationFrame(tick);
})();
